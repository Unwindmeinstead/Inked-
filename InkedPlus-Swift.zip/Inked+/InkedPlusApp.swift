// Inked+ SwiftUI App (macOS) — matches PWA/Electron UI and functionality.
// Open InkedPlus.xcodeproj in Xcode and run (⌘R) to build and launch.

import SwiftUI
import UserNotifications

// MARK: - Theme (matches PWA zinc/black palette)

extension Color {
    static let inkedBlack = Color.black
    static let inkedZinc900 = Color(red: 0.09, green: 0.09, blue: 0.11)      // zinc-900
    static let inkedZinc800 = Color(red: 0.15, green: 0.15, blue: 0.17)      // zinc-800
    static let inkedZinc700 = Color(red: 0.23, green: 0.23, blue: 0.25)     // zinc-700
    static let inkedZinc600 = Color(red: 0.35, green: 0.35, blue: 0.38)     // zinc-600
    static let inkedZinc500 = Color(red: 0.45, green: 0.45, blue: 0.48)      // zinc-500
    static let inkedZinc400 = Color(red: 0.55, green: 0.55, blue: 0.58)     // zinc-400
    static let inkedZinc300 = Color(red: 0.72, green: 0.72, blue: 0.74)     // zinc-300
    static let inkedZinc100 = Color(red: 0.93, green: 0.93, blue: 0.94)      // zinc-100
    static let inkedSelected = Color(red: 0.2, green: 0.15, blue: 0.35)     // blue/purple selected
    static let inkedAmber = Color(red: 0.98, green: 0.76, blue: 0.26)       // amber-400
    static let inkedRed = Color(red: 0.75, green: 0.2, blue: 0.2)           // red-500
}

// MARK: - Models

struct Notebook: Identifiable, Codable, Equatable {
    var id: String
    var name: String
}

struct NoteAttachment: Codable, Equatable {
    var name: String
    var data: String  // base64
}

struct Note: Identifiable, Codable, Equatable {
    var id: String
    var title: String
    var content: String
    var notebookId: String
    var starred: Bool
    var tags: [String]
    var reminderAt: Date?
    var deletedAt: Date?
    var attachments: [NoteAttachment]
    var createdAt: Date
    var updatedAt: Date

    init(id: String, title: String, content: String, notebookId: String, starred: Bool = false, tags: [String] = [], reminderAt: Date? = nil, deletedAt: Date? = nil, attachments: [NoteAttachment] = [], createdAt: Date, updatedAt: Date) {
        self.id = id
        self.title = title
        self.content = content
        self.notebookId = notebookId
        self.starred = starred
        self.tags = tags
        self.reminderAt = reminderAt
        self.deletedAt = deletedAt
        self.attachments = attachments
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }

    enum CodingKeys: String, CodingKey {
        case id, title, content, notebookId, starred, tags, reminderAt, deletedAt, attachments, createdAt, updatedAt
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(String.self, forKey: .id)
        title = try c.decode(String.self, forKey: .title)
        content = try c.decode(String.self, forKey: .content)
        notebookId = try c.decode(String.self, forKey: .notebookId)
        starred = try c.decodeIfPresent(Bool.self, forKey: .starred) ?? false
        tags = try c.decodeIfPresent([String].self, forKey: .tags) ?? []
        reminderAt = try c.decodeIfPresent(Date.self, forKey: .reminderAt)
        deletedAt = try c.decodeIfPresent(Date.self, forKey: .deletedAt)
        attachments = try c.decodeIfPresent([NoteAttachment].self, forKey: .attachments) ?? []
        createdAt = try c.decode(Date.self, forKey: .createdAt)
        updatedAt = try c.decode(Date.self, forKey: .updatedAt)
    }

    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(id, forKey: .id)
        try c.encode(title, forKey: .title)
        try c.encode(content, forKey: .content)
        try c.encode(notebookId, forKey: .notebookId)
        try c.encode(starred, forKey: .starred)
        try c.encode(tags, forKey: .tags)
        try c.encodeIfPresent(reminderAt, forKey: .reminderAt)
        try c.encodeIfPresent(deletedAt, forKey: .deletedAt)
        try c.encode(attachments, forKey: .attachments)
        try c.encode(createdAt, forKey: .createdAt)
        try c.encode(updatedAt, forKey: .updatedAt)
    }
}

// MARK: - Storage

final class AppStorage: ObservableObject {
    private let notebooksKey = "noted-plus-notebooks"
    private let notesKey = "noted-plus-notes"

    @Published var notebooks: [Notebook] = []
    @Published var notes: [Note] = []

    init() {
        loadNotebooks()
        loadNotes()
        if notebooks.isEmpty {
            notebooks = [
                Notebook(id: "1", name: "THINGS THAT NEEDS FIX"),
                Notebook(id: "2", name: "TAPASHYAS STUFF"),
                Notebook(id: "3", name: "AAHANS MEAL PLAN"),
            ]
            saveNotebooks()
        }
        if notes.isEmpty, let first = notebooks.first {
            notes = [
                Note(id: "1", title: "Lets get this straight", content: "But", notebookId: first.id, starred: false, createdAt: Date(), updatedAt: Date()),
            ]
            saveNotes()
        }
        scheduleReminderCheck()
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }

    private func loadNotebooks() {
        guard let data = UserDefaults.standard.data(forKey: notebooksKey),
              let decoded = try? JSONDecoder().decode([Notebook].self, from: data) else { return }
        notebooks = decoded
    }

    private func loadNotes() {
        guard let data = UserDefaults.standard.data(forKey: notesKey) else { return }
        let decoded = try? JSONDecoder().decode([Note].self, from: data)
        notes = decoded ?? []
    }

    func saveNotebooks() {
        guard let data = try? JSONEncoder().encode(notebooks) else { return }
        UserDefaults.standard.set(data, forKey: notebooksKey)
    }

    func saveNotes() {
        guard let data = try? JSONEncoder().encode(notes) else { return }
        UserDefaults.standard.set(data, forKey: notesKey)
    }

    func addNotebook(name: String) {
        let n = Notebook(id: UUID().uuidString, name: name.uppercased())
        notebooks.append(n)
        saveNotebooks()
    }

    func deleteNotebook(id: String) {
        notes.removeAll { $0.notebookId == id }
        notebooks.removeAll { $0.id == id }
        saveNotes()
        saveNotebooks()
    }

    func addNote(notebookId: String) {
        let n = Note(id: UUID().uuidString, title: "Untitled", content: "", notebookId: notebookId, starred: false, createdAt: Date(), updatedAt: Date())
        notes.insert(n, at: 0)
        saveNotes()
    }

    func updateNote(id: String, title: String? = nil, content: String? = nil, starred: Bool? = nil) {
        guard let i = notes.firstIndex(where: { $0.id == id }) else { return }
        if let t = title { notes[i].title = t }
        if let c = content { notes[i].content = c }
        if let s = starred { notes[i].starred = s }
        notes[i].updatedAt = Date()
        saveNotes()
    }

    func updateNoteTags(id: String, tags: [String]) {
        guard let i = notes.firstIndex(where: { $0.id == id }) else { return }
        notes[i].tags = tags
        notes[i].updatedAt = Date()
        saveNotes()
    }

    func updateNoteReminder(id: String, at: Date?) {
        guard let i = notes.firstIndex(where: { $0.id == id }) else { return }
        notes[i].reminderAt = at
        notes[i].updatedAt = Date()
        saveNotes()
    }

    func updateNoteAttachments(id: String, attachments: [NoteAttachment]) {
        guard let i = notes.firstIndex(where: { $0.id == id }) else { return }
        notes[i].attachments = attachments
        notes[i].updatedAt = Date()
        saveNotes()
    }

    func softDeleteNote(id: String) {
        guard let i = notes.firstIndex(where: { $0.id == id }) else { return }
        notes[i].deletedAt = Date()
        notes[i].updatedAt = Date()
        saveNotes()
    }

    func restoreNote(id: String) {
        guard let i = notes.firstIndex(where: { $0.id == id }) else { return }
        notes[i].deletedAt = nil
        notes[i].updatedAt = Date()
        saveNotes()
    }

    func permanentDeleteNote(id: String) {
        notes.removeAll { $0.id == id }
        saveNotes()
    }

    var activeNotes: [Note] { notes.filter { $0.deletedAt == nil } }
    var trashedNotes: [Note] { notes.filter { $0.deletedAt != nil } }

    func notes(for notebookId: String?, tag: String?, starred: Bool, trash: Bool) -> [Note] {
        let base = trash ? trashedNotes : activeNotes
        if trash { return base }
        var result = base
        if let nid = notebookId { result = result.filter { $0.notebookId == nid } }
        if let t = tag { result = result.filter { $0.tags.contains(t) } }
        if starred { result = result.filter { $0.starred } }
        return result.sorted { $0.updatedAt > $1.updatedAt }
    }

    var allTags: [String] {
        Array(Set(activeNotes.flatMap(\.tags))).sorted()
    }

    private func scheduleReminderCheck() {
        Timer.scheduledTimer(withTimeInterval: 15, repeats: true) { [weak self] _ in
            self?.fireDueReminders()
        }.fire()
    }

    private func fireDueReminders() {
        let now = Date()
        for (index, note) in notes.enumerated() {
            guard let at = note.reminderAt, at <= now else { continue }
            let content = UNMutableNotificationContent()
            content.title = note.title.isEmpty ? "Note reminder" : note.title
            content.body = "Reminder for this note"
            let request = UNNotificationRequest(identifier: note.id, content: content, trigger: nil)
            UNUserNotificationCenter.current().add(request)
            notes[index].reminderAt = nil
            saveNotes()
        }
    }
}

// MARK: - Main App

@main
struct InkedPlusApp: App {
    @StateObject private var storage = AppStorage()

    var body: some Scene {
        WindowGroup {
            ContentView(storage: storage)
                .preferredColorScheme(.dark)
        }
    }
}

// MARK: - Content View (3-column layout)

struct ContentView: View {
    @ObservedObject var storage: AppStorage
    @State private var currentNotebookId: String?
    @State private var currentNoteId: String?
    @State private var selectedTag: String?
    @State private var showStarred = false
    @State private var showTrash = false
    @State private var middlePanelOpen = true

    var body: some View {
        let notebookId = showTrash ? nil : (currentNotebookId ?? storage.notebooks.first?.id)
        let notesForList = storage.notes(for: notebookId, tag: selectedTag, starred: showStarred, trash: showTrash)
        let noteId = currentNoteId ?? notesForList.first?.id
        let note = noteId.flatMap { id in storage.notes.first { $0.id == id } }

        HStack(spacing: 0) {
            LeftSidebarView(
                notebooks: storage.notebooks,
                currentNotebookId: notebookId,
                allTags: storage.allTags,
                selectedTag: $selectedTag,
                showStarred: $showStarred,
                showTrash: $showTrash,
                onSelect: { currentNotebookId = $0; currentNoteId = nil; selectedTag = nil; showStarred = false; showTrash = false },
                onCreate: { storage.addNotebook(name: $0); currentNotebookId = storage.notebooks.last?.id },
                onDelete: { storage.deleteNotebook(id: $0); if currentNotebookId == $0 { currentNotebookId = storage.notebooks.first?.id }; currentNoteId = nil }
            )
            .frame(width: 200)

            MiddlePanelView(
                notes: notesForList,
                currentNoteId: noteId,
                showTrash: showTrash,
                notebookName: showTrash ? "Trash" : (showStarred ? "Starred" : (selectedTag != nil ? "Tag: \(selectedTag!)" : storage.notebooks.first(where: { $0.id == notebookId })?.name ?? "")),
                canCreate: notebookId != nil && !showTrash,
                onSelect: { currentNoteId = $0 },
                onCreate: { if let nid = notebookId { storage.addNote(notebookId: nid); currentNoteId = storage.notes.first?.id } },
                onDelete: { let id = $0; storage.softDeleteNote(id: id); if currentNoteId == id { currentNoteId = notesForList.first(where: { $0.id != id })?.id ?? notesForList.first?.id } },
                onRestore: { storage.restoreNote(id: $0); showTrash = false; currentNoteId = $0 },
                onPermanentDelete: { let id = $0; storage.permanentDeleteNote(id: id); if currentNoteId == id { currentNoteId = notesForList.first(where: { $0.id != id })?.id ?? notesForList.first?.id } }
            )
            .frame(width: middlePanelOpen ? 320 : 0)
            .clipped()
            .animation(.easeInOut(duration: 0.35), value: middlePanelOpen)

            if let n = note {
                EditorView(
                    note: n,
                    middlePanelOpen: middlePanelOpen,
                    onToggleMiddlePanel: { middlePanelOpen.toggle() },
                    onSave: { storage.updateNote(id: n.id, title: $0, content: $1) },
                    onStarChange: { storage.updateNote(id: n.id, starred: $0) },
                    onTagsChange: { storage.updateNoteTags(id: n.id, tags: $0) },
                    onReminderChange: { storage.updateNoteReminder(id: n.id, at: $0) },
                    onAttachmentsChange: { storage.updateNoteAttachments(id: n.id, attachments: $0) }
                )
            } else {
                VStack {
                    Text("Select a note")
                        .foregroundStyle(.secondary)
                        .font(.system(size: 18))
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.inkedBlack)
            }
        }
        .background(Color.inkedBlack)
        .onAppear {
            if currentNotebookId == nil { currentNotebookId = storage.notebooks.first?.id }
            if currentNoteId == nil {
                let list = storage.notes(for: currentNotebookId ?? storage.notebooks.first?.id, tag: nil, starred: false, trash: false)
                currentNoteId = list.first?.id
            }
        }
    }
}

// MARK: - Left Sidebar (matches PWA: Inked+ logo, Starred/Trash pills, Notebooks/Tags tabs)

struct LeftSidebarView: View {
    let notebooks: [Notebook]
    let currentNotebookId: String?
    let allTags: [String]
    @Binding var selectedTag: String?
    @Binding var showStarred: Bool
    @Binding var showTrash: Bool
    let onSelect: (String) -> Void
    let onCreate: (String) -> Void
    let onDelete: (String) -> Void

    @State private var search = ""
    @State private var showNewNotebook = false
    @State private var newNotebookName = ""
    @State private var deleteTarget: Notebook?
    @State private var activeTab = 0

    private var filteredNotebooks: [Notebook] {
        if search.isEmpty { return notebooks }
        return notebooks.filter { $0.name.localizedCaseInsensitiveContains(search) }
    }

    private var filteredTags: [String] {
        if search.isEmpty { return allTags }
        return allTags.filter { $0.localizedCaseInsensitiveContains(search) }
    }

    var body: some View {
        VStack(spacing: 0) {
            // Inked+ header
            HStack {
                Text("Inked")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(Color.inkedZinc100)
                Text("+")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(Color.inkedZinc100)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 12)
            .padding(.vertical, 12)
            .background(Color.inkedBlack)
            .overlay(alignment: .bottom) { Divider().background(Color.inkedZinc800).opacity(0.5) }

            // Starred / Trash pills
            HStack(spacing: 4) {
                Button {
                    showStarred.toggle()
                    showTrash = false
                    if showStarred { selectedTag = nil }
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "star.fill")
                            .font(.system(size: 12))
                            .foregroundStyle(showStarred ? Color.inkedAmber : Color.inkedZinc500)
                        Text("Starred")
                            .font(.system(size: 12, weight: .medium))
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                    .background(showStarred ? Color.inkedAmber.opacity(0.2) : Color.clear)
                    .foregroundStyle(showStarred ? Color.inkedAmber : Color.inkedZinc500)
                    .cornerRadius(8)
                }
                .buttonStyle(.plain)

                Button {
                    showTrash.toggle()
                    showStarred = false
                    if showTrash { selectedTag = nil }
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "trash")
                            .font(.system(size: 12))
                        Text("Trash")
                            .font(.system(size: 12, weight: .medium))
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                    .background(showTrash ? Color.inkedZinc700 : Color.clear)
                    .foregroundStyle(showTrash ? Color.inkedZinc100 : Color.inkedZinc500)
                    .cornerRadius(8)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 6)
            .background(Color.inkedBlack)
            .overlay(alignment: .bottom) { Divider().background(Color.inkedZinc800).opacity(0.5) }

            // Notebooks / Tags tabs (pill style)
            HStack(spacing: 0) {
                Button {
                    activeTab = 0
                    if showStarred || showTrash { showStarred = false; showTrash = false }
                } label: {
                    Text("Notebooks")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(activeTab == 0 ? Color.inkedZinc100 : Color.inkedZinc500)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .overlay(alignment: .bottom) {
                            if activeTab == 0 {
                                Rectangle().frame(height: 2).foregroundStyle(Color.blue)
                            }
                        }
                }
                .buttonStyle(.plain)

                Button {
                    activeTab = 1
                } label: {
                    Text("Tags")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(activeTab == 1 ? Color.inkedZinc100 : Color.inkedZinc500)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .overlay(alignment: .bottom) {
                            if activeTab == 1 {
                                Rectangle().frame(height: 2).foregroundStyle(Color.blue)
                            }
                        }
                }
                .buttonStyle(.plain)
            }
            .background(Color.inkedBlack)
            .overlay(alignment: .bottom) { Divider().background(Color.inkedZinc800).opacity(0.5) }

            // Search
            HStack {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 14))
                    .foregroundStyle(Color.inkedZinc500)
                TextField(activeTab == 1 ? "Search tags..." : "Search notebooks...", text: $search)
                    .textFieldStyle(.plain)
                    .font(.system(size: 14))
                    .foregroundStyle(Color.inkedZinc300)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color.inkedZinc900.opacity(0.5))
            .cornerRadius(8)
            .padding(8)

            // List
            if activeTab == 0 {
                ScrollView {
                    LazyVStack(spacing: 2) {
                        ForEach(filteredNotebooks) { nb in
                            HStack(spacing: 8) {
                                Image(systemName: "folder.fill")
                                    .font(.system(size: 14))
                                    .foregroundStyle(Color.inkedZinc400)
                                Text(nb.name)
                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundStyle(currentNotebookId == nb.id ? Color.inkedZinc100 : Color.inkedZinc400)
                                    .lineLimit(1)
                                Spacer()
                                Button {
                                    deleteTarget = nb
                                } label: {
                                    Image(systemName: "xmark")
                                        .font(.system(size: 12, weight: .medium))
                                        .foregroundStyle(Color.inkedRed)
                                }
                                .buttonStyle(.plain)
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 10)
                            .background(currentNotebookId == nb.id ? Color.inkedZinc800.opacity(0.8) : Color.clear)
                            .cornerRadius(8)
                            .contentShape(Rectangle())
                            .onTapGesture { onSelect(nb.id) }
                        }
                    }
                    .padding(.horizontal, 4)
                }
                .background(Color.inkedBlack)
            } else {
                ScrollView {
                    if filteredTags.isEmpty {
                        Text(allTags.isEmpty ? "No tags yet" : "No tags match your search")
                            .font(.system(size: 12))
                            .foregroundStyle(Color.inkedZinc500)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 24)
                    } else {
                        LazyVStack(spacing: 2) {
                            ForEach(filteredTags, id: \.self) { tag in
                                Text("#\(tag)")
                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundStyle(selectedTag == tag ? Color.inkedZinc100 : Color.inkedZinc400)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 10)
                                    .background(selectedTag == tag ? Color.inkedZinc800.opacity(0.8) : Color.clear)
                                    .cornerRadius(8)
                                    .contentShape(Rectangle())
                                    .onTapGesture { selectedTag = selectedTag == tag ? nil : tag }
                            }
                        }
                        .padding(.horizontal, 4)
                    }
                }
                .background(Color.inkedBlack)
            }

            Spacer(minLength: 0)

            // New Notebook button
            if activeTab == 0 {
                Button {
                    showNewNotebook = true
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "plus")
                            .font(.system(size: 14))
                        Text("New Notebook")
                            .font(.system(size: 14, weight: .light))
                    }
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(Color.inkedZinc900.opacity(0.8))
                    .cornerRadius(999)
                }
                .buttonStyle(.plain)
                .padding(12)
                .background(Color.inkedBlack)
                .overlay(alignment: .top) { Divider().background(Color.inkedZinc800).opacity(0.5) }
            }
        }
        .background(Color.inkedBlack)
        .alert("New Notebook", isPresented: $showNewNotebook) {
            TextField("Notebook name", text: $newNotebookName)
            Button("Cancel", role: .cancel) { showNewNotebook = false; newNotebookName = "" }
            Button("Create") {
                let name = newNotebookName.trimmingCharacters(in: .whitespacesAndNewlines)
                if !name.isEmpty { onCreate(name) }
                newNotebookName = ""
                showNewNotebook = false
            }
        } message: {
            Text("Enter notebook name")
        }
        .alert("Delete Notebook", isPresented: .init(get: { deleteTarget != nil }, set: { if !$0 { deleteTarget = nil } })) {
            Button("Cancel", role: .cancel) { deleteTarget = nil }
            Button("Delete", role: .destructive) {
                if let nb = deleteTarget { onDelete(nb.id) }
                deleteTarget = nil
            }
        } message: {
            if let nb = deleteTarget {
                Text("Delete \"\(nb.name)\"? All notes in this notebook will be removed. This cannot be undone.")
            }
        }
    }
}

// MARK: - Middle Panel (search bar, notes list with selected styling)

private struct MiddlePanelNoteRow: View {
    let note: Note
    let isSelected: Bool
    let showTrash: Bool
    let onSelect: () -> Void
    let onRestore: () -> Void
    let onDelete: () -> Void
    let relativeDate: (Date) -> String

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(note.title.isEmpty ? "Untitled" : note.title)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(isSelected ? Color.inkedZinc100 : Color.inkedZinc300)
                    .lineLimit(1)
                Spacer()
                if note.starred && !showTrash {
                    Image(systemName: "star.fill")
                        .font(.system(size: 12))
                        .foregroundStyle(Color.inkedAmber)
                }
                if showTrash {
                    Button(action: onRestore) {
                        Image(systemName: "arrow.uturn.backward")
                            .font(.system(size: 12))
                            .foregroundStyle(Color.inkedZinc400)
                    }
                    .buttonStyle(.plain)
                }
                Button(action: onDelete) {
                    Image(systemName: "trash")
                        .font(.system(size: 12))
                        .foregroundStyle(Color.inkedRed.opacity(0.9))
                }
                .buttonStyle(.plain)
            }
            if !note.tags.isEmpty {
                HStack(spacing: 4) {
                    ForEach(note.tags.prefix(3), id: \.self) { t in
                        Text("#\(t)")
                            .font(.system(size: 10))
                            .foregroundStyle(Color.inkedZinc400)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color.inkedZinc800.opacity(0.8))
                            .cornerRadius(4)
                    }
                }
            }
            Text(note.content)
                .font(.system(size: 12))
                .foregroundStyle(Color.inkedZinc500)
                .lineLimit(2)
            Text(relativeDate(note.updatedAt))
                .font(.system(size: 12))
                .foregroundStyle(Color.inkedZinc600)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            AnyShapeStyle(
                isSelected
                    ? LinearGradient(
                        colors: [Color.inkedSelected.opacity(0.2), Color.clear],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                    : LinearGradient(colors: [Color.clear, Color.clear], startPoint: .leading, endPoint: .trailing)
            )
        )
        .overlay(alignment: .leading) {
            if isSelected {
                Rectangle()
                    .fill(Color.blue)
                    .frame(width: 2)
            }
        }
        .contentShape(Rectangle())
        .onTapGesture(perform: onSelect)
    }
}

private struct MiddlePanelSearchBar: View {
    @Binding var search: String
    let canCreate: Bool
    let onCreate: () -> Void

    var body: some View {
        searchField
            .padding(12)
            .background(Color.inkedBlack)
            .overlay(alignment: .bottom) {
                Divider()
                    .background(Color.inkedZinc800)
                    .opacity(0.5)
            }
    }

    private var searchField: some View {
        HStack(spacing: 8) {
            searchInput
            addButton
        }
    }

    private var searchInput: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14))
                .foregroundStyle(Color.inkedZinc500)
            TextField("Search notes...", text: $search)
                .textFieldStyle(.plain)
                .font(.system(size: 14))
                .foregroundStyle(Color.inkedZinc300)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(Color.inkedZinc900.opacity(0.5))
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.inkedZinc800, lineWidth: 1)
        )
    }

    private var addButton: AnyView {
        AnyView(
            Button(action: onCreate) {
                Image(systemName: "plus")
                    .font(.system(size: 16))
                    .foregroundStyle(Color.inkedZinc400)
                    .frame(width: 36, height: 36)
                    .background(Color.inkedZinc900.opacity(0.5))
                    .cornerRadius(8)
            }
            .buttonStyle(.plain)
            .disabled(!canCreate)
        )
    }
}

struct MiddlePanelView: View {
    let notes: [Note]
    let currentNoteId: String?
    let showTrash: Bool
    let notebookName: String
    let canCreate: Bool
    let onSelect: (String) -> Void
    let onCreate: () -> Void
    let onDelete: (String) -> Void
    let onRestore: (String) -> Void
    let onPermanentDelete: (String) -> Void

    @State private var search = ""
    @State private var deleteTarget: Note?
    @State private var isPermanent = false

    private var filtered: [Note] {
        if search.isEmpty { return notes }
        return notes.filter {
            $0.title.localizedCaseInsensitiveContains(search) ||
            $0.content.localizedCaseInsensitiveContains(search) ||
            $0.tags.contains(where: { $0.localizedCaseInsensitiveContains(search) })
        }
    }

    private var emptyStateTitle: String {
        if search.isEmpty {
            return showTrash ? "Trash is empty" : "No notes yet"
        } else {
            return "No matching notes"
        }
    }

    private func deleteMessage(for note: Note, permanent: Bool) -> String {
        let title = note.title.isEmpty ? "Untitled" : note.title
        if permanent {
            return "Permanently delete \"\(title)\"? This cannot be undone."
        } else {
            return "Move \"\(title)\" to Trash?"
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            searchBar
            notesSection
        }
        .background(Color.inkedBlack)
        .alert(
            isPermanent ? "Delete Permanently" : "Delete Note",
            isPresented: .init(
                get: { deleteTarget != nil },
                set: { if !$0 { deleteTarget = nil } }
            )
        ) {
            Button("Cancel", role: .cancel) { deleteTarget = nil }
            Button(isPermanent ? "Delete Permanently" : "Delete", role: .destructive) {
                if let n = deleteTarget {
                    if isPermanent {
                        onPermanentDelete(n.id)
                    } else {
                        onDelete(n.id)
                    }
                }
                deleteTarget = nil
            }
        } message: {
            Text(deleteTarget.map { deleteMessage(for: $0, permanent: isPermanent) } ?? "")
        }
    }

    private var searchBar: some View {
        MiddlePanelSearchBar(search: $search, canCreate: canCreate, onCreate: onCreate)
    }

    private var noNotebookView: AnyView {
        AnyView(
            VStack(spacing: 4) {
                Text("No notebook selected")
                    .font(.system(size: 14))
                    .foregroundStyle(Color.inkedZinc500)
                Text("Select or create a notebook in the sidebar")
                    .font(.system(size: 12))
                    .foregroundStyle(Color.inkedZinc600)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        )
    }

    private var emptyStateView: AnyView {
        var v: AnyView
        if search.isEmpty && !showTrash {
            v = AnyView(
                VStack(spacing: 8) {
                    Text(emptyStateTitle)
                        .font(.system(size: 14))
                        .foregroundStyle(Color.inkedZinc500)
                    Button("Create first note", action: onCreate)
                        .font(.system(size: 14))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color.blue)
                        .cornerRadius(8)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            )
        } else {
            v = AnyView(
                Text(emptyStateTitle)
                    .font(.system(size: 14))
                    .foregroundStyle(Color.inkedZinc500)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            )
        }
        return v
    }

    private var notesListView: AnyView {
        AnyView(
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(filtered) { note in
                        MiddlePanelNoteRow(
                            note: note,
                            isSelected: currentNoteId == note.id,
                            showTrash: showTrash,
                            onSelect: { onSelect(note.id) },
                            onRestore: { onRestore(note.id) },
                            onDelete: {
                                deleteTarget = note
                                isPermanent = showTrash
                            },
                            relativeDate: relativeDate
                        )
                    }
                }
            }
            .background(Color.inkedBlack)
        )
    }

    private var notesSection: AnyView {
        if !canCreate && !showTrash {
            return AnyView(noNotebookView)
        } else if filtered.isEmpty {
            return AnyView(emptyStateView)
        } else {
            return AnyView(notesListView)
        }
    }

    private func relativeDate(_ d: Date) -> String {
        let c = Calendar.current.dateComponents([.day], from: d, to: Date())
        guard let days = c.day else { return "" }
        if days == 0 { return "Today" }
        if days == 1 { return "Yesterday" }
        if days < 7 { return "\(days) days ago" }
        if days < 30 { return "\(days / 7) weeks ago" }
        if days < 365 { return "\(days / 30) months ago" }
        return "\(days / 365) years ago"
    }
}

// MARK: - Editor View (title bar, content, word count — matches PWA)

struct EditorView: View {
    let note: Note
    var middlePanelOpen: Bool = true
    var onToggleMiddlePanel: (() -> Void)? = nil
    let onSave: (String, String) -> Void
    let onStarChange: (Bool) -> Void
    let onTagsChange: ([String]) -> Void
    let onReminderChange: (Date?) -> Void
    let onAttachmentsChange: ([NoteAttachment]) -> Void

    @State private var title: String
    @State private var content: String
    @State private var isSaving = false
    @State private var showSaved = false
    @State private var saveTask: Task<Void, Never>?
    @State private var showTagsSheet = false
    @State private var tagsText: String = ""
    @State private var showReminderSheet = false
    @State private var reminderDate: Date = Date().addingTimeInterval(3600)

    init(note: Note, middlePanelOpen: Bool, onToggleMiddlePanel: @escaping () -> Void, onSave: @escaping (String, String) -> Void, onStarChange: @escaping (Bool) -> Void, onTagsChange: @escaping ([String]) -> Void, onReminderChange: @escaping (Date?) -> Void, onAttachmentsChange: @escaping ([NoteAttachment]) -> Void) {
        self.note = note
        self.middlePanelOpen = middlePanelOpen
        self.onToggleMiddlePanel = onToggleMiddlePanel
        self.onSave = onSave
        self.onStarChange = onStarChange
        self.onTagsChange = onTagsChange
        self.onReminderChange = onReminderChange
        self.onAttachmentsChange = onAttachmentsChange
        _title = State(initialValue: note.title)
        _content = State(initialValue: note.content)
        _tagsText = State(initialValue: note.tags.joined(separator: ", "))
        _reminderDate = State(initialValue: note.reminderAt ?? Date().addingTimeInterval(3600))
    }

    var body: some View {
        VStack(spacing: 0) {
            // Title bar (dark purple/gray — matches PWA)
            HStack(spacing: 12) {
                TextField("Title", text: $title)
                    .font(.system(size: 18, weight: .medium))
                    .foregroundStyle(Color.inkedZinc100)
                    .onChange(of: title) { _ in scheduleSave() }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.inkedZinc900.opacity(0.5))
            .overlay(alignment: .bottom) { Divider().background(Color.inkedZinc800).opacity(0.5) }

            // Toolbar (panel toggle, star, tags, reminder — matches PWA)
            HStack(spacing: 8) {
                if let toggle = onToggleMiddlePanel {
                    Button(action: toggle) {
                        Image(systemName: middlePanelOpen ? "rectangle.leadinghalf.inset.filled" : "rectangle.trailinghalf.inset.filled")
                            .font(.system(size: 14))
                            .foregroundStyle(Color.inkedZinc400)
                            .frame(width: 32, height: 32)
                            .background(Color.inkedZinc900.opacity(0.5))
                            .clipShape(Circle())
                    }
                    .buttonStyle(.plain)
                }

                Button { onStarChange(!note.starred) } label: {
                    Image(systemName: note.starred ? "star.fill" : "star")
                        .font(.system(size: 14))
                        .foregroundStyle(note.starred ? Color.inkedAmber : Color.inkedZinc400)
                        .frame(width: 32, height: 32)
                        .background(Color.inkedZinc900.opacity(0.5))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)

                Button { showTagsSheet = true } label: {
                    Image(systemName: "number")
                        .font(.system(size: 14))
                        .foregroundStyle(Color.inkedRed.opacity(0.8))
                        .frame(width: 32, height: 32)
                        .background(Color.inkedZinc900.opacity(0.5))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)

                Button { showReminderSheet = true } label: {
                    Image(systemName: note.reminderAt != nil ? "bell.fill" : "bell")
                        .font(.system(size: 14))
                        .foregroundStyle(note.reminderAt != nil ? Color.inkedAmber : Color.inkedZinc400)
                        .frame(width: 32, height: 32)
                        .background(Color.inkedZinc900.opacity(0.5))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)

                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(Color.inkedBlack)

            // Content
            ScrollView {
                TextEditor(text: $content)
                    .font(.system(size: 16, weight: .light))
                    .foregroundStyle(Color.inkedZinc300)
                    .scrollContentBackground(.hidden)
                    .frame(minHeight: 400)
                    .padding(.horizontal, 24)
                    .padding(.vertical, 16)
                    .onChange(of: content) { _ in scheduleSave() }
            }
            .background(Color.inkedBlack)

            // Attachments
            if !note.attachments.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(Array(note.attachments.enumerated()), id: \.offset) { i, att in
                            HStack(spacing: 8) {
                                Image(systemName: "paperclip")
                                    .font(.system(size: 12))
                                    .foregroundStyle(Color.inkedZinc500)
                                Text(att.name)
                                    .font(.system(size: 12))
                                    .foregroundStyle(Color.inkedZinc300)
                                    .lineLimit(1)
                                Button {
                                    var a = note.attachments
                                    a.remove(at: i)
                                    onAttachmentsChange(a)
                                } label: {
                                    Image(systemName: "xmark")
                                        .font(.system(size: 10))
                                        .foregroundStyle(Color.inkedZinc500)
                                }
                                .buttonStyle(.plain)
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(Color.inkedZinc900.opacity(0.8))
                            .cornerRadius(8)
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 8)
                }
                .background(Color.inkedBlack)
                .overlay(alignment: .top) { Divider().background(Color.inkedZinc800).opacity(0.5) }
            }

            // Status bar: word count • char count
            HStack {
                if !note.tags.isEmpty {
                    Text(note.tags.map { "#\($0)" }.joined(separator: " "))
                        .font(.system(size: 11))
                        .foregroundStyle(Color.inkedZinc500)
                }
                Spacer()
                Text("\(content.words.count) words · \(content.count) chars")
                    .font(.system(size: 11))
                    .foregroundStyle(Color.inkedZinc500)
                if isSaving || showSaved {
                    Circle()
                        .fill(Color.inkedRed.opacity(showSaved ? 0.4 : 0.8))
                        .frame(width: 6, height: 6)
                }
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 8)
            .background(Color.inkedBlack)
            .overlay(alignment: .top) { Divider().background(Color.inkedZinc800).opacity(0.5) }
        }
        .background(Color.inkedBlack)
        .onAppear {
            title = note.title
            content = note.content
            tagsText = note.tags.joined(separator: ", ")
        }
        .sheet(isPresented: $showTagsSheet) {
            VStack(spacing: 16) {
                Text("Edit tags")
                    .font(.headline)
                    .frame(maxWidth: .infinity, alignment: .leading)
                TextField("Tags (comma-separated)", text: $tagsText)
                    .textFieldStyle(.roundedBorder)
                HStack {
                    Button("Cancel") { showTagsSheet = false }
                    Spacer()
                    Button("Save") {
                        let tags = tagsText.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
                        onTagsChange(tags)
                        showTagsSheet = false
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
            .padding(24)
            .frame(width: 400)
        }
        .sheet(isPresented: $showReminderSheet) {
            VStack(spacing: 16) {
                Text("Reminder")
                    .font(.headline)
                    .frame(maxWidth: .infinity, alignment: .leading)
                DatePicker("Remind me", selection: $reminderDate)
                if note.reminderAt != nil {
                    Button("Clear reminder", role: .destructive) {
                        onReminderChange(nil)
                        showReminderSheet = false
                    }
                }
                HStack {
                    Button("Cancel") { showReminderSheet = false }
                    Spacer()
                    Button("Set") {
                        onReminderChange(reminderDate)
                        showReminderSheet = false
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
            .padding(24)
            .frame(width: 400)
        }
    }

    private func scheduleSave() {
        isSaving = true
        showSaved = false
        saveTask?.cancel()
        saveTask = Task {
            try? await Task.sleep(nanoseconds: 600_000_000)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                onSave(title, content)
                isSaving = false
                showSaved = true
                Task { @MainActor in
                    try? await Task.sleep(nanoseconds: 1_800_000_000)
                    showSaved = false
                }
            }
        }
    }
}

extension String {
    var words: [String] {
        components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty }
    }
}
