# Inked+ (Swift / macOS)

SwiftUI **Mac** version of **Inked+** — notebooks, notes list, editor with autosave, **tags**, and **reminders** (aligned with the web/Electron app).

## Run in Xcode (Mac)

1. Open **InkedPlus.xcodeproj** in Xcode (double-click or `open InkedPlus.xcodeproj`).
2. Select the **Inked+** scheme and **My Mac** as the run destination.
3. Press **⌘R** to build and run.

The project is set up for **macOS 13+** and includes **InkedPlusApp.swift** and **Assets.xcassets** (add your Inked+ logo to AppIcon if desired).

## Features

- **Notebooks** sidebar: create, delete, search (in-app alert for new notebook name).
- **Tags** tab: list all tags; tap to filter notes by tag.
- **Notes** list: create, delete, search; shows tags and reminder indicator; relative dates.
- **Editor**: title + body, autosave, word/char count, **Edit tags** (sheet), **Reminder** (sheet with date picker; local notifications when due).
- **Persistence**: `UserDefaults` (keys: `noted-plus-notebooks`, `noted-plus-notes`).

## Optional: Speech & AI

Use `SFSpeechRecognizer` for voice-to-text (add mic/speech permissions in Info.plist). For Groq AI, call `https://api.groq.com/openai/v1/chat/completions` with your API key.
